import ProductsPage from "../components/products-page"

export default function Home() {
  return (
    <main className="min-h-screen">
      <ProductsPage />
    </main>
  )
}
